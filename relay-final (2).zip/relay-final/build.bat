@echo off
REM ============================================================
REM  GERA UM UNICO ARQUIVO: Relay.jar (com a interface embutida)
REM  Compila mirando Java 17 (--release 17), para rodar em
REM  QUALQUER PC com Java 17 ou mais novo — nao so no seu.
REM
REM  Rode este .bat UMA VEZ. Depois use so o Relay.jar.
REM  Precisa do JDK (voce ja tem por causa do Spring).
REM ============================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo Compilando (mirando Java 17, para compatibilidade ampla)...
javac --release 17 Relay.java
if errorlevel 1 (
  echo.
  echo [ERRO] Falha ao compilar. O JDK esta instalado?  Teste: javac -version
  pause
  exit /b 1
)

echo Localizando o jar.exe...
set JARBIN=

REM 1) Tenta JAVA_HOME, se definido
if defined JAVA_HOME (
  if exist "%JAVA_HOME%\bin\jar.exe" set "JARBIN=%JAVA_HOME%\bin\"
)

REM 2) Procura nas pastas reais de instalacao (ignora o atalho "javapath"
REM    da Oracle, que so tem java/javac e NAO tem jar.exe)
if not defined JARBIN (
  for /f "delims=" %%F in ('dir /s /b "C:\Program Files\Java\jar.exe" 2^>nul') do (
    if not defined JARBIN for %%G in ("%%F") do set "JARBIN=%%~dpG"
  )
)
if not defined JARBIN (
  for /f "delims=" %%F in ('dir /s /b "C:\Program Files\Eclipse Adoptium\jar.exe" 2^>nul') do (
    if not defined JARBIN for %%G in ("%%F") do set "JARBIN=%%~dpG"
  )
)
if not defined JARBIN (
  for /f "delims=" %%F in ('dir /s /b "C:\Program Files (x86)\Java\jar.exe" 2^>nul') do (
    if not defined JARBIN for %%G in ("%%F") do set "JARBIN=%%~dpG"
  )
)

REM 3) Se ainda nao achou, pede para digitar
if not defined JARBIN (
  echo Nao encontrei o jar.exe automaticamente.
  echo Digite o caminho da pasta "bin" do seu JDK e aperte Enter.
  echo Exemplo:  C:\Program Files\Java\jdk-24.0.2\bin\
  set /p JARBIN="Caminho: "
)

if not exist "!JARBIN!jar.exe" (
  echo.
  echo [ERRO] jar.exe nao encontrado em: !JARBIN!
  echo Confira se o JDK esta instalado corretamente ^(nao so o JRE^).
  pause
  exit /b 1
)

echo Encontrado: !JARBIN!jar.exe
echo Empacotando a interface dentro do .jar...
"!JARBIN!jar.exe" --create --file Relay.jar --main-class Relay Relay.class ui.html
if errorlevel 1 (
  echo.
  echo [ERRO] Falha ao gerar o .jar.
  pause
  exit /b 1
)

del Relay.class 2>nul

echo.
echo [OK] Relay.jar gerado com a interface embutida!
echo Compilado para rodar em qualquer PC com Java 17 ou mais novo.
echo.
echo Agora voce tem UM arquivo so: Relay.jar
echo  - Dois cliques nele abre o Relay (a UI ja esta dentro).
echo  - Pode copiar o Relay.jar sozinho para qualquer PC com Java.
echo  - Nao precisa mais do ui.html nem do Relay.java ao lado.
echo.
pause
