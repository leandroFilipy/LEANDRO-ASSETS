// Relay — API Request Builder com proxy local (Java puro, sem dependências).
//
// Serve a interface e faz de proxy das requisições. Como as chamadas saem
// deste processo (não do navegador), NÃO há CORS, mixed content nem origem
// nula — funciona igual a um Postman, inclusive contra http://localhost:8080
// sem tocar no backend.
//
// Precisa apenas do JDK (que você já tem, por causa do Spring).
//
// Como rodar (a partir de Java 11, sem compilar nada):
//     java Relay.java
//
// Ou compilar e gerar um .jar portátil (roda em qualquer PC com Java):
//     javac Relay.java
//     jar --create --file relay.jar --main-class Relay Relay.class
//     java -jar relay.jar
//
// O arquivo ui.html precisa estar na MESMA pasta do Relay.java / relay.jar.

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Relay {

    static byte[] uiBytes;

    // HttpClient único e compartilhado, com cookie jar: o Set-Cookie do login
    // (ex.: JSESSIONID) fica guardado e é reenviado nas próximas requisições,
    // mantendo a sessão autenticada — igual ao Postman.
    static volatile HttpClient shared;

    static HttpClient sharedClient() {
        if (shared == null) {
            synchronized (Relay.class) {
                if (shared == null) {
                    CookieManager cm = new CookieManager();
                    cm.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
                    shared = HttpClient.newBuilder()
                            .connectTimeout(Duration.ofSeconds(15))
                            .followRedirects(HttpClient.Redirect.NORMAL)
                            .cookieHandler(cm)
                            .build();
                }
            }
        }
        return shared;
    }

    public static void main(String[] args) throws Exception {
        uiBytes = loadUI();

        int port = firstFreePort(8787);
        String url = "http://127.0.0.1:" + port;

        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);

        server.createContext("/", exchange -> {
            if (!exchange.getRequestURI().getPath().equals("/")) {
                send(exchange, 404, "text/plain", "not found".getBytes(StandardCharsets.UTF_8));
                return;
            }
            send(exchange, 200, "text/html; charset=utf-8", uiBytes);
        });

        server.createContext("/proxy", Relay::handleProxy);

        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(8));
        server.start();

        System.out.println("==================================================");
        System.out.println("  Relay - API Request Builder");
        System.out.println("--------------------------------------------------");
        System.out.println("  Aberto em: " + url);
        System.out.println("  Deixe esta janela aberta enquanto usar.");
        System.out.println("  Para fechar o Relay, feche esta janela.");
        System.out.println("==================================================");

        openBrowser(url);
    }

    // ---- carrega ui.html da mesma pasta do programa ----
    static byte[] loadUI() {
        // 1) tenta como recurso embutido no jar
        try (InputStream in = Relay.class.getResourceAsStream("/ui.html")) {
            if (in != null) return in.readAllBytes();
        } catch (IOException ignored) {}
        // 2) tenta na pasta atual
        String[] candidates = { "ui.html", "./ui.html" };
        for (String c : candidates) {
            Path p = Paths.get(c);
            if (Files.exists(p)) {
                try { return Files.readAllBytes(p); } catch (IOException ignored) {}
            }
        }
        String msg = "<h1>ui.html nao encontrado</h1>"
                + "<p>Coloque o arquivo <b>ui.html</b> na mesma pasta do Relay.</p>";
        return msg.getBytes(StandardCharsets.UTF_8);
    }

    // ---- proxy: refaz a requisicao do lado do servidor ----
    static void handleProxy(HttpExchange exchange) throws IOException {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            sendJson(exchange, err("metodo interno invalido"));
            return;
        }

        String bodyIn = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);

        String method = jsonString(bodyIn, "method");
        String url    = jsonString(bodyIn, "url");
        String reqBody = jsonRawString(bodyIn, "body"); // pode ser null
        List<String[]> headers = jsonHeaders(bodyIn);

        if (url == null || url.trim().isEmpty()) {
            sendJson(exchange, err("informe uma URL"));
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            sendJson(exchange, err("a URL precisa comecar com http:// ou https://"));
            return;
        }
        if (method == null || method.isEmpty()) method = "GET";

        try {
            HttpClient client = sharedClient();

            HttpRequest.BodyPublisher pub =
                    (reqBody == null || method.equalsIgnoreCase("GET") || method.equalsIgnoreCase("HEAD"))
                            ? HttpRequest.BodyPublishers.noBody()
                            : HttpRequest.BodyPublishers.ofString(reqBody);

            HttpRequest.Builder rb = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .timeout(Duration.ofSeconds(30))
                    .method(method.toUpperCase(), pub);

            for (String[] h : headers) {
                String k = h[0], v = h[1];
                if (k == null || k.trim().isEmpty()) continue;
                // alguns headers sao restritos; ignore silenciosamente se der erro
                try { rb.header(k, v); } catch (IllegalArgumentException ignored) {}
            }

            HttpResponse<byte[]> res = client.send(rb.build(), HttpResponse.BodyHandlers.ofByteArray());

            StringBuilder json = new StringBuilder();
            json.append('{');
            json.append("\"status\":").append(res.statusCode()).append(',');
            json.append("\"statusText\":\"").append(esc(statusText(res.statusCode()))).append("\",");
            json.append("\"headers\":{");
            Map<String, List<String>> hs = new TreeMap<>(res.headers().map());
            boolean first = true;
            for (Map.Entry<String, List<String>> e : hs.entrySet()) {
                if (e.getKey() == null) continue;
                if (!first) json.append(',');
                first = false;
                json.append('"').append(esc(e.getKey())).append("\":\"")
                        .append(esc(String.join(", ", e.getValue()))).append('"');
            }
            json.append("},");
            json.append("\"body\":\"").append(esc(new String(res.body(), StandardCharsets.UTF_8))).append('"');
            json.append('}');

            sendJson(exchange, json.toString());

        } catch (Exception e) {
            sendJson(exchange, err(friendly(e)));
        }
    }

    static String friendly(Exception e) {
        String s = String.valueOf(e.getMessage());
        String low = s == null ? "" : s.toLowerCase();
        if (low.contains("refused"))
            return "conexao recusada — o host esta no ar e a porta correta? (" + s + ")";
        if (low.contains("unknownhost") || e instanceof java.net.UnknownHostException)
            return "host nao encontrado — verifique o endereco (" + s + ")";
        if (low.contains("timed out") || low.contains("timeout"))
            return "tempo esgotado — o host demorou a responder (" + s + ")";
        if (low.contains("certificate") || low.contains("ssl") || low.contains("tls"))
            return "problema no certificado TLS do host (" + s + ")";
        return e.getClass().getSimpleName() + ": " + s;
    }

    // =================== JSON mínimo (sem libs) ===================
    // Extrai o valor string de uma chave de nível superior: "key":"...."
    static String jsonString(String json, String key) {
        String raw = jsonRawString(json, key);
        return raw;
    }

    // Retorna a string desescapada do valor da chave, ou null se for JSON null/ausente.
    static String jsonRawString(String json, String key) {
        String pat = "\"" + key + "\"";
        int i = json.indexOf(pat);
        if (i < 0) return null;
        i += pat.length();
        // pula espacos e ':'
        while (i < json.length() && (json.charAt(i) == ' ' || json.charAt(i) == ':')) i++;
        if (i >= json.length()) return null;
        char c = json.charAt(i);
        if (c == 'n') return null; // null
        if (c != '"') return null;
        i++;
        StringBuilder sb = new StringBuilder();
        while (i < json.length()) {
            char ch = json.charAt(i++);
            if (ch == '\\') {
                if (i >= json.length()) break;
                char n = json.charAt(i++);
                switch (n) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'u':
                        if (i + 4 <= json.length()) {
                            String hex = json.substring(i, i + 4);
                            i += 4;
                            try { sb.append((char) Integer.parseInt(hex, 16)); } catch (Exception ignored) {}
                        }
                        break;
                    default: sb.append(n);
                }
            } else if (ch == '"') {
                break;
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    // Extrai os pares do objeto "headers":{ "k":"v", ... }
    static List<String[]> jsonHeaders(String json) {
        List<String[]> out = new ArrayList<>();
        int h = json.indexOf("\"headers\"");
        if (h < 0) return out;
        int brace = json.indexOf('{', h);
        if (brace < 0) return out;
        int depth = 0, i = brace;
        int end = -1;
        for (; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '{') depth++;
            else if (c == '}') { depth--; if (depth == 0) { end = i; break; } }
        }
        if (end < 0) return out;
        String obj = json.substring(brace + 1, end);
        // parse simples de pares "k":"v"
        int p = 0;
        while (p < obj.length()) {
            int q1 = obj.indexOf('"', p);
            if (q1 < 0) break;
            int q2 = obj.indexOf('"', q1 + 1);
            if (q2 < 0) break;
            String key = unescape(obj.substring(q1 + 1, q2));
            int colon = obj.indexOf(':', q2);
            if (colon < 0) break;
            int q3 = obj.indexOf('"', colon);
            if (q3 < 0) break;
            // valor pode ter aspas escapadas
            StringBuilder val = new StringBuilder();
            int k = q3 + 1;
            while (k < obj.length()) {
                char ch = obj.charAt(k++);
                if (ch == '\\' && k < obj.length()) { val.append(ch).append(obj.charAt(k++)); }
                else if (ch == '"') break;
                else val.append(ch);
            }
            out.add(new String[]{ key, unescape(val.toString()) });
            p = k;
        }
        return out;
    }

    static String unescape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 't': sb.append('\t'); break;
                    case 'r': sb.append('\r'); break;
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    default: sb.append(n);
                }
            } else sb.append(c);
        }
        return sb.toString();
    }

    static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.toString();
    }

    static String err(String msg) {
        return "{\"error\":\"" + esc(msg) + "\"}";
    }

    static String statusText(int code) {
        switch (code) {
            case 200: return "OK";
            case 201: return "Created";
            case 202: return "Accepted";
            case 204: return "No Content";
            case 301: return "Moved Permanently";
            case 302: return "Found";
            case 304: return "Not Modified";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 405: return "Method Not Allowed";
            case 409: return "Conflict";
            case 422: return "Unprocessable Entity";
            case 429: return "Too Many Requests";
            case 500: return "Internal Server Error";
            case 502: return "Bad Gateway";
            case 503: return "Service Unavailable";
            default:  return "";
        }
    }

    // =================== util HTTP ===================
    static void send(HttpExchange ex, int code, String contentType, byte[] body) throws IOException {
        ex.getResponseHeaders().set("Content-Type", contentType);
        ex.sendResponseHeaders(code, body.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(body); }
    }

    static void sendJson(HttpExchange ex, String json) throws IOException {
        send(ex, 200, "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8));
    }

    static int firstFreePort(int start) {
        for (int p = start; p < start + 50; p++) {
            try (ServerSocket s = new ServerSocket()) {
                s.bind(new InetSocketAddress("127.0.0.1", p));
                return p;
            } catch (IOException ignored) {}
        }
        return start;
    }

    static void openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(url));
                return;
            }
        } catch (Exception ignored) {}
        // fallback Windows
        try {
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
                return;
            }
        } catch (Exception ignored) {}
        System.out.println("Abra manualmente no navegador: " + url);
    }
}
