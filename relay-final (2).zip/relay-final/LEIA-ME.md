# Relay

## Passo único
1. Descompacte esta pasta inteira (Relay.java, ui.html, build.bat,
   Relay.bat precisam ficar juntos, na mesma pasta).
2. Dois cliques em **build.bat**.
3. Vai aparecer um **Relay.jar** aqui do lado.

## Usar
Dois cliques em **Relay.bat** -> abre o navegador sozinho no Relay.

## Levar para outro PC
Copie **Relay.jar + Relay.bat** juntos, na mesma pasta lá. Só precisa
de Java instalado no PC de destino.
